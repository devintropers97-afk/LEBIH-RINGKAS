# REKAP GABUNGAN LENGKAP - SITUNEO DIGITAL
## BATCH 2: PORTFOLIO & PRICING PAGES

---

# 📄 FILE 2: LANJUTAN38 - PORTFOLIO PAGE

## Fungsi Utama
Halaman **Display Portfolio** dengan 50+ demo website, filter kategori, dan pencarian real-time.

## Struktur Lengkap

### 1. PHP BACKEND (Baris 1-42)

**Database Query:**
```php
$portfolios = [];
$result = $conn->query("SELECT * FROM portfolios WHERE status = 'active' ORDER BY id DESC");
while ($row = $result->fetch_assoc()) {
    $portfolios[] = $row;
}
```

**Category Management:**
```php
$categories = array_unique(array_column($portfolios, 'category'));
$category_count = [];
foreach ($categories as $cat) {
    $category_count[$cat] = count(array_filter($portfolios, 
        fn($p) => $p['category'] === $cat));
}
```

**Features:**
- Auto-detect unique categories dari database
- Count portfolio per kategori
- Status filter (hanya 'active')
- Order by ID descending (terbaru dulu)

### 2. KOMPONEN UI

#### A. Hero Section
```
Title: "Portfolio Kami"
Subtitle: "50+ Website Telah Kami Bangun"
Description: Showcase karya terbaik
Background: Gradient + Radial overlay
Min-height: 60vh
```

#### B. Search Section
**Search Bar:**
- Icon: Bootstrap Icons search
- Placeholder: "Cari portfolio..."
- Real-time search (keyup event)
- Enter key support
- Gold border on focus
- Glow effect

**Search Logic:**
```javascript
- Filter by title (case-insensitive)
- Filter by category
- Show/hide no results message
- Count visible items
```

#### C. Category Filters
**Filter Buttons:**
- "All" button (default active)
- Dynamic category buttons dari database
- Badge dengan jumlah portfolio
- Active state indicator (gold background)
- Horizontal scroll untuk mobile
- Smooth transition (0.3s)

**Filter Logic:**
```javascript
filterPortfolios(category) {
  items.forEach(item => {
    if (category === 'all' || item.dataset.category === category) {
      item.style.display = 'block';
      visibleCount++;
    } else {
      item.style.display = 'none';
    }
  });
}
```

#### D. Portfolio Grid
**Card Structure:**
```html
<div class="portfolio-item" data-category="E-Commerce">
  <img src="image.jpg" alt="Title">
  <div class="card-body">
    <span class="badge">E-Commerce</span>
    <h3>Portfolio Title</h3>
    <p>Description...</p>
    <div class="meta">
      <span><i class="bi-eye"></i> 1234 views</span>
    </div>
    <div class="actions">
      <a href="#" class="btn-view">View Demo</a>
      <a href="whatsapp" class="btn-order">Order</a>
    </div>
  </div>
</div>
```

**Grid Layout:**
- Desktop (>992px): 4 columns
- Tablet (768-992px): 3 columns
- Small tablet (576-768px): 2 columns
- Mobile (<576px): 1 column

**Card Effects:**
- Hover: translateY(-10px) + scale(1.02)
- Image zoom: scale(1.1) on hover
- Glow effect: box-shadow dengan gold
- Smooth transitions: 0.3s ease
- Glass-morphism: backdrop-blur(10px)

#### E. Modal Detail Portfolio
**Trigger:** Click pada portfolio card

**Modal Content:**
```html
<div class="modal">
  <img src="large-image.jpg">
  <div class="modal-body">
    <span class="category-badge">Category</span>
    <h2>Portfolio Title</h2>
    <p>Full Description...</p>
    <div class="modal-actions">
      <a href="demo-url" class="btn-view">View Demo</a>
      <a href="whatsapp" class="btn-order">Order via WhatsApp</a>
    </div>
  </div>
</div>
```

**Modal Features:**
- Backdrop blur effect
- Close button (X)
- Click outside to close
- Escape key to close
- Auto-increment view count (frontend simulation)
- Smooth fade-in animation

**View Counter:**
```javascript
incrementViewCount(id) {
  // Frontend simulation (perlu AJAX untuk real update)
  viewElement.textContent = parseInt(viewElement.textContent) + 1;
}
```

### 3. JAVASCRIPT FUNCTIONS

#### A. Network Background Animation
**Same as Contact Page:**
- 80 particles
- Canvas-based
- Connection lines
- Smooth 60fps animation

#### B. Portfolio Functions
```javascript
// Filter by category
function filterPortfolios(category) {
  - Update active button
  - Show/hide items by category
  - Update visible count
}

// Open detail modal
function openModal(portfolioId) {
  - Find portfolio data
  - Populate modal
  - Show modal
  - Increment view count
}

// Close modal
function closeModal() {
  - Hide modal
  - Clear modal content
}

// Search portfolios
searchButton.addEventListener('click', () => {
  - Get search query
  - Filter by title or category
  - Show/hide items
  - Show no results if empty
});
```

#### C. Event Listeners
```javascript
- window.onscroll → Navbar effect
- searchInput.keypress → Search on Enter
- modalBackdrop.click → Close modal
- escapeKey → Close modal
- window.resize → Canvas resize
```

## 📊 DATABASE SCHEMA

### Table: portfolios
```sql
CREATE TABLE portfolios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  category VARCHAR(100) NOT NULL,
  description TEXT,
  image VARCHAR(255),
  url VARCHAR(255),
  status ENUM('active', 'inactive') DEFAULT 'active',
  views INT DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

**Indexes:**
- PRIMARY KEY (id)
- INDEX (status)
- INDEX (category)
- INDEX (created_at)

## 🎯 Kategori Portfolio (Dinamis)

**Examples:**
- E-Commerce (Toko Online)
- F&B (Food & Beverage)
- Corporate (Company Profile)
- Healthcare (Klinik, Rumah Sakit)
- Education (Sekolah, Kursus)
- Real Estate
- Technology
- Creative Agency
- Dan lainnya... (auto-detect dari database)

## 📞 WhatsApp Integration

**Floating Button:**
```
Link: https://wa.me/6283173868915
Message: "Halo Situneo, saya mau tanya tentang portfolio"
```

**Order Button (per portfolio):**
```javascript
href: `https://wa.me/6283173868915?text=Halo, saya mau pesan website seperti ${portfolio.title}`
```

## ✅ Fitur yang Sudah Ada

1. ✅ Display 50+ portfolio
2. ✅ Filter kategori dinamis
3. ✅ Real-time search
4. ✅ Detail modal popup
5. ✅ View counter
6. ✅ WhatsApp integration
7. ✅ Responsive grid layout
8. ✅ Hover effects & animations
9. ✅ Glass-morphism design
10. ✅ Network background animation
11. ✅ No results message
12. ✅ Category badges
13. ✅ Call-to-action buttons

## ⚠️ Improvements Needed

1. ❌ **AJAX View Counter**
   - Real database update via AJAX
   - Prevent duplicate counts

2. ❌ **Pagination**
   - Load more button
   - Infinite scroll
   - Limit items per page

3. ❌ **Loading States**
   - Skeleton loaders
   - Spinner on filter change

4. ❌ **Image Optimization**
   - Lazy loading images
   - WebP format
   - Responsive images (srcset)

5. ❌ **Error Handling**
   - Database connection errors
   - Empty results handling
   - Broken image fallback

6. ❌ **Advanced Filters**
   - Multiple category selection
   - Sort by (date, views, name)
   - Price range filter

7. ❌ **Portfolio Detail Page**
   - Separate URL per portfolio
   - SEO-friendly URLs
   - Social share buttons

8. ❌ **Admin Panel**
   - CRUD operations
   - Bulk actions
   - Status management

## 🎯 Kesimpulan File Lanjutan38

**Rating: ⭐⭐⭐⭐½ (4.5/5)**

### Kelebihan:
✅ Design premium & modern  
✅ Interactive filters  
✅ Real-time search  
✅ Responsive layout  
✅ Database integration  
✅ Modal detail lengkap  
✅ WhatsApp integration  
✅ Performance optimized  

### Kekurangan:
⚠️ View count hanya simulasi  
⚠️ Belum ada pagination  
⚠️ No error handling  
⚠️ Images belum lazy load  

### Use Case:
Perfect untuk showcase portfolio agency, gallery website, atau product catalog.

---

# 📄 FILE 3: LANJUTAN39 - PRICING PAGE

## Fungsi Utama
Halaman **Harga Paket** dengan 6 tier pricing, comparison table, dan FAQ.

## Struktur Lengkap

### 1. PHP BACKEND (Baris 1-199)

**Database Settings:**
```php
$result = $conn->query("SELECT setting_key, setting_value FROM settings");
while ($row = $result->fetch_assoc()) {
    $settings[$row['setting_key']] = $row['setting_value'];
}
```

**6 Paket Layanan Hardcoded:**

#### PAKET 1: STARTER
```php
[
  'name' => 'Starter',
  'price' => 'Rp 1.500.000',
  'period' => '/ tahun',
  'description' => 'Bisnis baru mulai digitalisasi',
  'features' => [
    'Website 5 halaman',
    'Responsive Design',
    'Basic SEO Setup',
    'Contact Form',
    '1x Revisi',
    'SSL Certificate',
    'Free Domain (.my.id)',
    '1GB Hosting',
    'Email Support',
    '6 bulan maintenance'
  ],
  'not_included' => [
    'Custom Design',
    'Advanced SEO',
    'Content Creation',
    'Social Media Integration',
    'Analytics Setup'
  ]
]
```

#### PAKET 2: PROFESSIONAL ⭐ (POPULER)
```php
[
  'name' => 'Professional',
  'price' => 'Rp 3.500.000',
  'period' => '/ tahun',
  'popular' => true,
  'description' => 'Bisnis serius dengan online presence',
  'features' => [
    'Website 10 halaman',
    'Custom Design',
    'Advanced SEO Setup',
    'Contact Form + Quote Form',
    '3x Revisi',
    'SSL Certificate',
    'Free Domain (.com/.id)',
    '5GB Hosting',
    'Email + Phone Support',
    '1 tahun maintenance',
    'Google Analytics Setup',
    'Social Media Integration'
  ],
  'not_included' => [
    'E-Commerce Functionality',
    'Content Creation',
    'Monthly SEO Optimization',
    'PPC Advertising Setup'
  ]
]
```

#### PAKET 3: E-COMMERCE
```php
[
  'name' => 'E-Commerce',
  'price' => 'Rp 5.000.000',
  'period' => '/ tahun',
  'description' => 'Toko online dengan fitur lengkap',
  'features' => [
    'Toko Online Lengkap',
    'Payment Gateway Integration',
    'Product Management System',
    'Shopping Cart & Checkout',
    'Order Management',
    'Inventory Management',
    'Custom Design',
    'Advanced SEO Setup',
    'SSL Certificate',
    'Free Domain (.com/.id)',
    '10GB Hosting',
    'Email + Phone Support',
    '1 tahun maintenance',
    'Google Analytics Setup'
  ],
  'not_included' => [
    'Content Creation',
    'Monthly SEO Optimization',
    'PPC Advertising Setup',
    'Social Media Management'
  ]
]
```

#### PAKET 4: BUSINESS
```php
[
  'name' => 'Business',
  'price' => 'Rp 7.500.000',
  'period' => '/ tahun',
  'description' => 'Bisnis dengan kebutuhan digital kompleks',
  'features' => [
    'Custom Web Application',
    'Advanced Database System',
    'User Management System',
    'Payment Gateway Integration',
    'API Development',
    'Custom Design',
    'Advanced SEO Setup',
    'SSL Certificate',
    'Free Domain (.com/.id)',
    '20GB Hosting',
    'Priority Support',
    '1 tahun maintenance',
    'Google Analytics Setup',
    'Performance Optimization'
  ],
  'not_included' => [
    'Content Creation',
    'Monthly SEO Optimization',
    'PPC Advertising Setup',
    'Social Media Management'
  ]
]
```

#### PAKET 5: ENTERPRISE
```php
[
  'name' => 'Enterprise',
  'price' => 'Rp 15.000.000',
  'period' => '/ tahun',
  'description' => 'Perusahaan besar dengan kebutuhan khusus',
  'features' => [
    'Custom Enterprise Solution',
    'Advanced Database Architecture',
    'Multi-Role User System',
    'Advanced Analytics Dashboard',
    'API Integration (Multiple)',
    'Custom Design',
    'Advanced SEO Setup',
    'SSL Certificate',
    'Free Domain (.com/.id)',
    'Unlimited Hosting',
    'Dedicated Support',
    '2 tahun maintenance',
    'Google Analytics Setup',
    'Performance Optimization',
    'Security Audit',
    'Training & Documentation'
  ],
  'not_included' => [
    'Content Creation',
    'Monthly SEO Optimization',
    'PPC Advertising Setup',
    'Social Media Management'
  ]
]
```

#### PAKET 6: CUSTOM
```php
[
  'name' => 'Custom',
  'price' => 'Custom',
  'period' => '(sesuai kebutuhan)',
  'description' => 'Bisnis dengan kebutuhan sangat spesifik',
  'features' => [
    'Konsultasi Gratis',
    'Analisis Kebutuhan Bisnis',
    'Solusi Custom Design',
    'Fitur Sesuai Permintaan',
    'Timeline Disesuaikan',
    'Budget Fleksibel',
    'Tim Ahli Berpengalaman',
    'Support Prioritas',
    'Garansi Kepuasan'
  ],
  'not_included' => [
    'Fitur yang tidak disepakati dalam konsultasi awal'
  ]
]
```

### 2. KOMPONEN UI

#### A. Hero Section
```
Title: "Paket Harga Kami" (gradient text)
Subtitle: "Solusi Digital untuk Setiap Bisnis"
Description: Pilih paket sesuai kebutuhan
CTA Button: "Konsultasi Gratis" → WhatsApp
Background: Particle animation
```

#### B. Pricing Cards Grid
**Layout:**
- Desktop: 3 columns
- Tablet: 2 columns
- Mobile: 1 column

**Card Structure:**
```html
<div class="pricing-card">
  <span class="badge">POPULER</span> <!-- jika popular -->
  <h3>Nama Paket</h3>
  <div class="price">Harga <span class="period">/ tahun</span></div>
  <p class="description">Deskripsi paket</p>
  
  <ul class="features">
    <li><i class="bi-check-circle-fill"></i> Feature 1</li>
    <li><i class="bi-check-circle-fill"></i> Feature 2</li>
    ...
  </ul>
  
  <ul class="not-included">
    <li><i class="bi-x-circle-fill"></i> Not included 1</li>
    ...
  </ul>
  
  <a href="whatsapp" class="btn-order">Pesan Sekarang</a>
</div>
```

**Card Effects:**
- Popular badge (gold background)
- Hover: scale(1.05) + shadow
- Smooth transitions
- Glass-morphism style
- Gold gradient for CTA button

#### C. Comparison Table
**Table Structure:**
```html
<table class="comparison-table">
  <thead>
    <tr>
      <th>Fitur</th>
      <th>Starter</th>
      <th class="popular">Professional</th>
      <th>E-Commerce</th>
      <th>Business</th>
      <th>Enterprise</th>
      <th>Custom</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Jumlah Halaman</td>
      <td>5</td>
      <td>10</td>
      <td>Unlimited</td>
      <td>Unlimited</td>
      <td>Unlimited</td>
      <td>Custom</td>
    </tr>
    <!-- ... more rows ... -->
  </tbody>
</table>
```

**Table Features:**
- Sticky header (position: sticky)
- Horizontal scroll on mobile
- Highlight popular column (gold background)
- Checkmark/cross icons untuk yes/no
- Responsive width

**Fitur yang Dibandingkan:**
- Jumlah halaman
- Custom design
- SEO level
- Revisi count
- SSL Certificate
- Domain type
- Hosting capacity
- Support type
- Maintenance duration
- Analytics
- Payment gateway
- API development
- Training

#### D. FAQ Section
**6 Pertanyaan:**

1. **Apa yang membedakan setiap paket?**
   - Jawaban: Perbedaan fitur, halaman, support

2. **Apakah harga sudah termasuk hosting dan domain?**
   - Jawaban: Ya, sudah termasuk untuk 1 tahun

3. **Bagaimana jika ingin upgrade paket?**
   - Jawaban: Bisa upgrade kapan saja, bayar selisih

4. **Apakah ada biaya tersembunyi?**
   - Jawaban: Tidak ada, harga sudah all-in

5. **Berapa lama proses pengerjaan?**
   - Jawaban: 7-14 hari (Starter), 30-60 hari (Enterprise)

6. **Apakah bisa custom fitur di luar paket?**
   - Jawaban: Ya, pilih paket Custom atau add-on

**FAQ UI:**
- Accordion style
- Icon rotation on toggle
- Smooth expand/collapse
- Gold accent for active

#### E. CTA Section
```
Background: Gradient (blue to dark)
Title: "Masih Bingung Pilih Paket?"
Description: Konsultasi gratis dengan tim kami
Button: "Hubungi Kami" → WhatsApp
```

### 3. JAVASCRIPT FEATURES

#### A. Particle Animation
**Same as previous files:**
- 80 particles
- Canvas-based
- Connection lines
- Smooth animation

#### B. Navbar Scroll Effect
```javascript
window.scroll > 100px → {
  navbar.classList.add('scrolled');
  // Add blur background
  // Change padding
}
```

#### C. FAQ Toggle
```javascript
function toggleFaq(index) {
  const answer = document.getElementById(`faq-answer-${index}`);
  const icon = answer.previousElementSibling.querySelector('i');
  
  answer.classList.toggle('show');
  icon.classList.toggle('rotate');
}
```

#### D. AOS Initialization
```javascript
AOS.init({
  duration: 1000,
  once: true,
  offset: 100
});
```

## 📞 WhatsApp Integration (Per Paket)

**Starter:**
```
https://wa.me/6283173868915?text=Halo, saya mau pesan paket Starter
```

**Professional:**
```
https://wa.me/6283173868915?text=Halo, saya mau pesan paket Professional
```

**Dan seterusnya untuk setiap paket...**

## ✅ Fitur yang Sudah Ada

1. ✅ 6 paket pricing lengkap
2. ✅ Badge "POPULER" untuk best seller
3. ✅ Comparison table detail
4. ✅ FAQ section 6 pertanyaan
5. ✅ Responsive pricing cards
6. ✅ WhatsApp integration per paket
7. ✅ CTA section konsultasi
8. ✅ Particle background animation
9. ✅ Hover effects & transitions
10. ✅ Glass-morphism design
11. ✅ Gradient buttons
12. ✅ SEO-friendly meta tags

## ⚠️ Improvements Needed

1. ❌ **Dynamic Pricing dari Database**
   - Buat tabel packages
   - Admin panel untuk manage harga
   - Real-time update

2. ❌ **Add-ons System**
   - Extra features bisa dibeli terpisah
   - Calculate total price

3. ❌ **Currency Converter**
   - USD/EUR option
   - Real-time exchange rate

4. ❌ **Promo/Discount System**
   - Seasonal discounts
   - Coupon codes
   - Timer countdown

5. ❌ **Package Comparison Tool**
   - Side-by-side comparison
   - Highlight differences
   - Recommendation engine

6. ❌ **Payment Integration**
   - Direct checkout
   - Payment gateway
   - Invoice generation

7. ❌ **Package Customizer**
   - Build custom package
   - Select features
   - Auto-calculate price

## 🎯 Kesimpulan File Lanjutan39

**Rating: ⭐⭐⭐⭐ (4/5)**

### Kelebihan:
✅ 6 tier pricing jelas  
✅ Comparison table lengkap  
✅ FAQ helpful  
✅ Design dark luxury  
✅ WhatsApp integration  
✅ Responsive layout  
✅ Popular badge highlight  
✅ Particle animation  

### Kekurangan:
⚠️ Hardcoded pricing (not dynamic)  
⚠️ No payment integration  
⚠️ No add-ons system  
⚠️ No promo/discount feature  

### Use Case:
Perfect untuk agency, SaaS product, atau service-based business dengan multiple pricing tiers.

---

**END OF BATCH 2**

_Lanjut ke Batch 3: User Profile & Admin Services_
