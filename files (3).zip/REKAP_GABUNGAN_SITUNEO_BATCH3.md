# REKAP GABUNGAN LENGKAP - SITUNEO DIGITAL
## BATCH 3: USER PROFILE & ADMIN MANAGEMENT

---

# 📄 FILE 4: LANJUTAN40 - USER PROFILE PAGE

## Fungsi Utama
Halaman **User Profile Management** dengan update profil, ubah password, dan upload avatar.

## Struktur Lengkap

### 1. PHP BACKEND (Baris 1-150)

#### A. Konfigurasi & Authentication
```php
require_once 'config.php';
requireLogin(); // Wajib login
$user = getCurrentUser(); // Ambil data user dari session
```

#### B. Update Profil (Baris 21-55)
**POST Handler: update_profile**

```php
if (isset($_POST['update_profile'])) {
    $name = trim($_POST['name']);
    $phone = trim($_POST['phone']);
    $address = trim($_POST['address']);
    
    // Validasi
    if (empty($name) || empty($phone)) {
        $error = "Nama dan telepon wajib diisi!";
    } else {
        // Update database
        $stmt = $conn->prepare("UPDATE users SET name = ?, phone = ?, address = ? WHERE id = ?");
        $stmt->bind_param("sssi", $name, $phone, $address, $user['id']);
        
        if ($stmt->execute()) {
            $_SESSION['user_name'] = $name; // Update session
            logActivity($user['id'], 'Profile updated');
            $success = "Profil berhasil diperbarui!";
        }
    }
}
```

**Fields:**
- name (required)
- phone (required)
- address (optional)

**Actions:**
- Update database
- Update session name
- Log activity
- Show success message

#### C. Ubah Password (Baris 58-99)
**POST Handler: change_password**

```php
if (isset($_POST['change_password'])) {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    
    // Validasi password lama
    if (!verifyPassword($current_password, $user['password'])) {
        $password_error = "Password saat ini salah!";
    }
    // Validasi panjang password
    elseif (strlen($new_password) < 8) {
        $password_error = "Password baru minimal 8 karakter!";
    }
    // Validasi konfirmasi
    elseif ($new_password !== $confirm_password) {
        $password_error = "Konfirmasi password tidak cocok!";
    }
    else {
        $hashed_password = hashPassword($new_password);
        $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
        $stmt->bind_param("si", $hashed_password, $user['id']);
        
        if ($stmt->execute()) {
            logActivity($user['id'], 'Password changed');
            $password_success = "Password berhasil diubah!";
        }
    }
}
```

**Validations:**
- Current password must be correct
- New password min 8 characters
- Confirm password must match
- Password hashing dengan hashPassword()

#### D. Upload Avatar (Baris 102-149)
**POST Handler: $_FILES['avatar']**

```php
if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] === UPLOAD_ERR_OK) {
    $file = $_FILES['avatar'];
    $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
    $max_size = 2 * 1024 * 1024; // 2MB
    
    // Validasi tipe file
    if (!in_array($file['type'], $allowed_types)) {
        $avatar_error = "Tipe file tidak diizinkan!";
    }
    // Validasi ukuran
    elseif ($file['size'] > $max_size) {
        $avatar_error = "Ukuran file maksimal 2MB!";
    }
    else {
        $upload_dir = '../uploads/avatars/';
        
        // Create directory if not exists
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        
        // Generate unique filename
        $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = 'avatar_' . $user['id'] . '_' . time() . '.' . $extension;
        $upload_path = $upload_dir . $filename;
        
        // Move uploaded file
        if (move_uploaded_file($file['tmp_name'], $upload_path)) {
            // Update database
            $stmt = $conn->prepare("UPDATE users SET avatar = ? WHERE id = ?");
            $stmt->bind_param("si", $filename, $user['id']);
            
            if ($stmt->execute()) {
                logActivity($user['id'], 'Avatar updated');
                $avatar_success = "Avatar berhasil diupdate!";
                // Refresh user data
                $user = getCurrentUser();
            }
        }
    }
}
```

**Validations:**
- File type: JPEG, PNG, GIF only
- File size: Max 2MB
- Unique filename: avatar_{user_id}_{timestamp}.{ext}
- Auto-create upload directory

### 2. KOMPONEN UI (Baris 152-961)

#### A. Head Section (Baris 154-170)
```html
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Profil Saya - SITUNEO DIGITAL</title>

<!-- Favicon -->
<link rel="icon" href="https://situneo.my.id/favicon.ico">

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Plus+Jakarta+Sans:wght@400;600;700;800;900&display=swap">

<!-- Bootstrap 5.3.3 -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

<!-- AOS Animation -->
<link href="https://unpkg.com/aos@2.3.1/dist/aos.css">
```

#### B. CSS Styling (Baris 171-746)

**CSS Variables:**
```css
:root {
  --primary-blue: #1E5C99;
  --dark-blue: #0F3057;
  --gold: #FFB400;
  --bright-gold: #FFD700;
  --white: #ffffff;
  --text-light: #e9ecef;
  --gradient-primary: linear-gradient(135deg, #1E5C99, #0F3057);
  --gradient-gold: linear-gradient(135deg, #FFD700, #FFB400);
}
```

**Key Components Styled:**
1. **Network Background:**
   - Position: fixed, fullscreen
   - Canvas animation
   - Opacity: 0.3

2. **Circuit Pattern:**
   - Grid background
   - Animated movement
   - Gold lines overlay

3. **Navbar Premium:**
   - Fixed top position
   - Backdrop blur on scroll
   - Glass-morphism effect
   - User dropdown menu

4. **Sidebar:**
   - Fixed left position
   - Navigation menu
   - Active state styling
   - Hover effects
   - Mobile: collapsible

5. **Profile Header Card:**
   - Avatar display (150x150px)
   - User info (name, email, join date)
   - Upload avatar button
   - Glass-morphism card

6. **Form Cards:**
   - Edit profil form
   - Change password form
   - Input styling
   - Button styling
   - Error/success alerts

#### C. Navbar (Baris 621-704)
```html
<nav class="navbar">
  <div class="navbar-brand">
    <button class="sidebar-toggle">
      <i class="bi-list"></i>
    </button>
    <span>SITUNEO DIGITAL</span>
  </div>
  
  <div class="navbar-end">
    <div class="user-profile">
      <img src="avatar.jpg" class="user-avatar">
      <span class="user-name"><?= $user['name'] ?></span>
      <div class="dropdown-menu">
        <a href="profile.php">Profil Saya</a>
        <a href="settings.php">Pengaturan</a>
        <a href="logout.php">Keluar</a>
      </div>
    </div>
  </div>
</nav>
```

**Features:**
- Sidebar toggle button (mobile)
- Logo/brand name
- User avatar + name
- Dropdown menu
- Scroll effect (blur background)

#### D. Sidebar Menu (Baris 665-704)
```html
<aside class="sidebar">
  <div class="sidebar-header">
    <img src="logo.png" alt="Logo">
    <h3>Dashboard</h3>
  </div>
  
  <nav class="sidebar-menu">
    <a href="dashboard.php">
      <i class="bi-speedometer2"></i>
      <span>Dashboard</span>
    </a>
    <a href="projects.php">
      <i class="bi-folder"></i>
      <span>Projects</span>
    </a>
    <a href="team.php">
      <i class="bi-people"></i>
      <span>Team</span>
    </a>
    <a href="settings.php">
      <i class="bi-gear"></i>
      <span>Settings</span>
    </a>
    <a href="logout.php">
      <i class="bi-box-arrow-right"></i>
      <span>Keluar</span>
    </a>
  </nav>
</aside>
```

**Menu Items:**
- Dashboard
- Projects
- Team
- Settings
- Keluar (Logout)

**Styling:**
- Active state indicator
- Hover effects
- Icon + text layout
- Gold accent for active

#### E. Main Content (Baris 705-801)

**1. Profile Header Card:**
```html
<div class="profile-header-card">
  <div class="avatar-section">
    <img src="<?= $user['avatar'] ?>" alt="Avatar" class="profile-avatar">
    <button class="btn-change-avatar" onclick="document.getElementById('avatarInput').click()">
      <i class="bi-camera"></i> Ubah Avatar
    </button>
    <input type="file" id="avatarInput" name="avatar" accept="image/*" style="display:none;">
  </div>
  
  <div class="user-info">
    <h2><?= $user['name'] ?></h2>
    <p class="user-email"><?= $user['email'] ?></p>
    <p class="user-joined">Bergabung sejak <?= date('F Y', strtotime($user['created_at'])) ?></p>
  </div>
</div>
```

**2. Form Edit Profil:**
```html
<form method="POST" class="profile-form">
  <div class="form-group">
    <label>Nama Lengkap</label>
    <input type="text" name="name" value="<?= $user['name'] ?>" required>
  </div>
  
  <div class="form-group">
    <label>Email</label>
    <input type="email" value="<?= $user['email'] ?>" readonly>
  </div>
  
  <div class="form-group">
    <label>Nomor Telepon</label>
    <input type="tel" name="phone" value="<?= $user['phone'] ?>" required>
  </div>
  
  <div class="form-group">
    <label>Alamat</label>
    <textarea name="address" rows="3"><?= $user['address'] ?></textarea>
  </div>
  
  <button type="submit" name="update_profile" class="btn-primary">
    Simpan Perubahan
  </button>
</form>
```

**3. Form Ubah Password:**
```html
<form method="POST" class="password-form">
  <div class="row">
    <div class="col-md-4">
      <label>Password Saat Ini</label>
      <input type="password" name="current_password" required>
    </div>
    <div class="col-md-4">
      <label>Password Baru</label>
      <input type="password" name="new_password" required>
    </div>
    <div class="col-md-4">
      <label>Konfirmasi Password</label>
      <input type="password" name="confirm_password" required>
    </div>
  </div>
  
  <button type="submit" name="change_password" class="btn-primary">
    Ubah Password
  </button>
</form>
```

### 3. JAVASCRIPT (Baris 802-959)

#### A. AOS Initialization
```javascript
AOS.init({
    duration: 1000,
    once: true
});
```

#### B. Network Background Animation
**Node Class:**
```javascript
class Node {
    constructor() {
        this.x = Math.random() * canvas.width;
        this.y = Math.random() * canvas.height;
        this.vx = (Math.random() - 0.5) * 0.5;
        this.vy = (Math.random() - 0.5) * 0.5;
        this.radius = Math.random() * 2 + 1;
    }
    
    update() {
        this.x += this.vx;
        this.y += this.vy;
        
        // Bounce on borders
        if (this.x < 0 || this.x > canvas.width) this.vx *= -1;
        if (this.y < 0 || this.y > canvas.height) this.vy *= -1;
    }
    
    draw() {
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(255, 180, 0, 0.5)';
        ctx.fill();
    }
}
```

**Animation Loop:**
```javascript
function animate() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Update & draw nodes
    nodes.forEach(node => {
        node.update();
        node.draw();
    });
    
    // Draw connections
    for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
            const dx = nodes[i].x - nodes[j].x;
            const dy = nodes[i].y - nodes[j].y;
            const distance = Math.sqrt(dx * dx + dy * dy);
            
            if (distance < 150) {
                ctx.beginPath();
                ctx.moveTo(nodes[i].x, nodes[i].y);
                ctx.lineTo(nodes[j].x, nodes[j].y);
                ctx.strokeStyle = `rgba(255, 180, 0, ${1 - distance / 150})`;
                ctx.stroke();
            }
        }
    }
    
    requestAnimationFrame(animate);
}
```

**Features:**
- 50 nodes bergerak
- Connection lines jika jarak < 150px
- Opacity based on distance
- Smooth 60fps animation
- Auto-resize on window change

#### C. Sidebar Toggle (Mobile)
```javascript
document.querySelector('.sidebar-toggle').addEventListener('click', () => {
    document.querySelector('.sidebar').classList.toggle('show');
});
```

#### D. Navbar Scroll Effect
```javascript
window.addEventListener('scroll', () => {
    if (window.scrollY > 50) {
        document.querySelector('.navbar').classList.add('scrolled');
    } else {
        document.querySelector('.navbar').classList.remove('scrolled');
    }
});
```

#### E. Avatar Upload Handler
```javascript
document.getElementById('avatarInput').addEventListener('change', function() {
    if (this.files && this.files[0]) {
        // Auto-submit form
        const form = document.createElement('form');
        form.method = 'POST';
        form.enctype = 'multipart/form-data';
        
        const fileInput = this.cloneNode(true);
        form.appendChild(fileInput);
        
        document.body.appendChild(form);
        form.submit();
    }
});
```

#### F. Form Validations

**Profile Form Validation:**
```javascript
document.querySelector('.profile-form').addEventListener('submit', function(e) {
    const name = this.querySelector('[name="name"]').value.trim();
    const phone = this.querySelector('[name="phone"]').value.trim();
    
    if (!name || !phone) {
        e.preventDefault();
        alert('Nama dan telepon wajib diisi!');
        return false;
    }
});
```

**Password Form Validation:**
```javascript
document.querySelector('.password-form').addEventListener('submit', function(e) {
    const current = this.querySelector('[name="current_password"]').value;
    const newPass = this.querySelector('[name="new_password"]').value;
    const confirm = this.querySelector('[name="confirm_password"]').value;
    
    if (!current || !newPass || !confirm) {
        e.preventDefault();
        alert('Semua field password wajib diisi!');
        return false;
    }
    
    if (newPass !== confirm) {
        e.preventDefault();
        alert('Konfirmasi password tidak cocok!');
        return false;
    }
    
    if (newPass.length < 8) {
        e.preventDefault();
        alert('Password minimal 8 karakter!');
        return false;
    }
});
```

## 📊 DATABASE SCHEMA

### Table: users
```sql
CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255) UNIQUE NOT NULL,
  phone VARCHAR(50),
  address TEXT,
  password VARCHAR(255) NOT NULL,
  avatar VARCHAR(255),
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

### Table: activity_logs
```sql
CREATE TABLE activity_logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  activity VARCHAR(255) NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
);
```

## 🔐 Security Features

1. **Authentication:** requireLogin() check
2. **SQL Injection:** Prepared statements
3. **Password Security:** hashPassword() & verifyPassword()
4. **File Upload Security:**
   - Type validation (JPEG, PNG, GIF)
   - Size validation (max 2MB)
   - Unique filename generation
5. **XSS Prevention:** htmlspecialchars() for output
6. **Session Management:** Update session on profile change
7. **Activity Logging:** All actions tracked

## ✅ Fitur yang Sudah Ada

1. ✅ Update profil (name, phone, address)
2. ✅ Change password with validation
3. ✅ Upload avatar (2MB max)
4. ✅ Real-time form validation
5. ✅ Network background animation
6. ✅ Responsive design
7. ✅ Glass-morphism UI
8. ✅ Activity logging
9. ✅ Session management
10. ✅ Success/error notifications
11. ✅ Sidebar navigation
12. ✅ Navbar with user dropdown

## ⚠️ Improvements Needed

1. ❌ **Avatar Crop Tool**
   - Client-side cropping
   - Preview before upload
   - Aspect ratio lock

2. ❌ **Email Verification**
   - Email change requires verification
   - Send verification link

3. ❌ **Two-Factor Authentication**
   - Enable 2FA option
   - QR code generation
   - Backup codes

4. ❌ **Profile Completion**
   - Progress bar
   - Missing fields indicator
   - Profile strength meter

5. ❌ **Avatar Gallery**
   - Multiple avatars
   - Choose from gallery
   - Default avatars

6. ❌ **Password Strength Meter**
   - Real-time strength indicator
   - Suggestions for strong password

7. ❌ **Activity Log Viewer**
   - View recent activities
   - Login history
   - Device tracking

## 🎯 Kesimpulan File Lanjutan40

**Rating: ⭐⭐⭐⭐½ (4.5/5)**

### Kelebihan:
✅ Complete profile management  
✅ Secure password change  
✅ Avatar upload system  
✅ Beautiful UI design  
✅ Form validation  
✅ Activity logging  
✅ Responsive layout  
✅ Network animation  

### Kekurangan:
⚠️ No avatar cropping  
⚠️ No email verification  
⚠️ No 2FA  
⚠️ No activity log viewer  

### Use Case:
Perfect untuk user profile page di web application, dashboard, atau member area.

---

# 📄 FILE 5: LANJUTAN45 - ADMIN SERVICES MANAGEMENT

## Fungsi Utama
**Admin Panel** untuk manajemen layanan (CRUD operations + filtering).

## Struktur Lengkap

### 1. PHP BACKEND (Baris 1-240)

#### A. Konfigurasi & Authentication (Baris 1-28)
```php
require_once 'config.php';

// Require admin role
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== ROLE_ADMIN) {
    header('Location: login.php');
    exit;
}

$user = getCurrentUser();

// Pagination & Filter Parameters
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$per_page = 12;
$offset = ($page - 1) * $per_page;

$filter_category = isset($_GET['category']) ? $_GET['category'] : '';
$filter_status = isset($_GET['status']) ? $_GET['status'] : '';
$search = isset($_GET['search']) ? $_GET['search'] : '';
```

**Access Control:**
- Check user role = ROLE_ADMIN
- Redirect to login if not admin
- Get current user data

**Filter Parameters:**
- category (service category)
- status (active/inactive)
- search (name/description)
- page (pagination)

#### B. Query Building with Filters (Baris 29-76)
```php
// Base query
$where = ["1=1"];
$params = [];
$types = "";

// Filter by category
if (!empty($filter_category)) {
    $where[] = "category = ?";
    $params[] = $filter_category;
    $types .= "s";
}

// Filter by status
if (!empty($filter_status)) {
    $where[] = "status = ?";
    $params[] = $filter_status;
    $types .= "s";
}

// Search by name or description
if (!empty($search)) {
    $where[] = "(name LIKE ? OR description LIKE ?)";
    $search_param = "%{$search}%";
    $params[] = $search_param;
    $params[] = $search_param;
    $types .= "ss";
}

$where_clause = implode(" AND ", $where);

// Count total services
$count_query = "SELECT COUNT(*) as total FROM services WHERE {$where_clause}";
$stmt = $conn->prepare($count_query);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$total = $stmt->get_result()->fetch_assoc()['total'];
$total_pages = ceil($total / $per_page);

// Get services with filters
$query = "SELECT * FROM services WHERE {$where_clause} ORDER BY created_at DESC LIMIT ? OFFSET ?";
$params[] = $per_page;
$params[] = $offset;
$types .= "ii";

$stmt = $conn->prepare($query);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$services = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Get all unique categories
$categories = $conn->query("SELECT DISTINCT category FROM services ORDER BY category")->fetch_all(MYSQLI_ASSOC);
```

**Query Features:**
- Dynamic WHERE clause
- Prepared statements
- Multiple filters (AND logic)
- LIKE search (name + description)
- Pagination (LIMIT + OFFSET)
- Get unique categories

#### C. Service Detail (Baris 78-91)
```php
if (isset($_GET['id']) && isset($_GET['action']) && $_GET['action'] === 'view') {
    $service_id = (int)$_GET['id'];
    
    $stmt = $conn->prepare("SELECT * FROM services WHERE id = ?");
    $stmt->bind_param("i", $service_id);
    $stmt->execute();
    $service_detail = $stmt->get_result()->fetch_assoc();
}
```

**Feature:**
- View single service detail
- Pass to modal

#### D. Update Status (Baris 93-110)
```php
if (isset($_POST['update_status'])) {
    $service_id = (int)$_POST['service_id'];
    $status = $_POST['status'];
    
    $stmt = $conn->prepare("UPDATE services SET status = ?, updated_at = NOW() WHERE id = ?");
    $stmt->bind_param("si", $status, $service_id);
    
    if ($stmt->execute()) {
        logActivity($user['id'], "Updated service status (ID: {$service_id})");
        header('Location: services.php?success=Status berhasil diupdate');
        exit;
    }
}
```

**Actions:**
- Update service status (active/inactive)
- Log activity
- Redirect with success message

#### E. Update Service (Baris 112-166)
```php
if (isset($_POST['update_service'])) {
    $service_id = (int)$_POST['service_id'];
    $name = trim($_POST['name']);
    $category = trim($_POST['category']);
    $description = trim($_POST['description']);
    $price_start = (float)$_POST['price_start'];
    $price_unit = trim($_POST['price_unit']);
    $image = trim($_POST['image']);
    $perfect_for = trim($_POST['perfect_for']);
    $delivery_time = trim($_POST['delivery_time']);
    
    // Convert features array to JSON
    $features = isset($_POST['features']) ? json_encode($_POST['features']) : '[]';
    
    // Validation
    if (empty($name) || empty($category) || empty($description) || empty($price_start) || empty($price_unit)) {
        $error = "Semua field wajib diisi!";
    } else {
        $stmt = $conn->prepare("UPDATE services SET name = ?, category = ?, description = ?, price_start = ?, price_unit = ?, image = ?, features = ?, perfect_for = ?, delivery_time = ?, updated_at = NOW() WHERE id = ?");
        $stmt->bind_param("sssdsssssi", $name, $category, $description, $price_start, $price_unit, $image, $features, $perfect_for, $delivery_time, $service_id);
        
        if ($stmt->execute()) {
            logActivity($user['id'], "Updated service: {$name}");
            header('Location: services.php?success=Layanan berhasil diupdate');
            exit;
        }
    }
}
```

**Validations:**
- name (required)
- category (required)
- description (required)
- price_start (required, float)
- price_unit (required)

**Features Array:**
- Multiple features input
- Convert to JSON before save
- Dynamic add/remove features

#### F. Add Service (Baris 168-221)
```php
if (isset($_POST['add_service'])) {
    $name = trim($_POST['name']);
    $category = trim($_POST['category']);
    $description = trim($_POST['description']);
    $price_start = (float)$_POST['price_start'];
    $price_unit = trim($_POST['price_unit']);
    $image = trim($_POST['image']);
    $perfect_for = trim($_POST['perfect_for']);
    $delivery_time = trim($_POST['delivery_time']);
    $status = 'active'; // Default
    
    // Convert features array to JSON
    $features = isset($_POST['features']) ? json_encode($_POST['features']) : '[]';
    
    // Validation
    if (empty($name) || empty($category) || empty($description) || empty($price_start) || empty($price_unit)) {
        $error = "Semua field wajib diisi!";
    } else {
        $stmt = $conn->prepare("INSERT INTO services (name, category, description, price_start, price_unit, image, features, perfect_for, delivery_time, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())");
        $stmt->bind_param("sssdssssss", $name, $category, $description, $price_start, $price_unit, $image, $features, $perfect_for, $delivery_time, $status);
        
        if ($stmt->execute()) {
            logActivity($user['id'], "Added new service: {$name}");
            header('Location: services.php?success=Layanan berhasil ditambahkan');
            exit;
        }
    }
}
```

**Default Values:**
- status = 'active'
- created_at = NOW()
- updated_at = NOW()

#### G. Delete Service (Baris 222-240)
```php
if (isset($_POST['delete_service'])) {
    $service_id = (int)$_POST['service_id'];
    
    // Get service name for logging
    $stmt = $conn->prepare("SELECT name FROM services WHERE id = ?");
    $stmt->bind_param("i", $service_id);
    $stmt->execute();
    $service_name = $stmt->get_result()->fetch_assoc()['name'];
    
    // Delete service
    $stmt = $conn->prepare("DELETE FROM services WHERE id = ?");
    $stmt->bind_param("i", $service_id);
    
    if ($stmt->execute()) {
        logActivity($user['id'], "Deleted service: {$service_name}");
        header('Location: services.php?success=Layanan berhasil dihapus');
        exit;
    }
}
```

**Actions:**
- Get service name first (for logging)
- Delete from database
- Log activity with service name
- Redirect with success

### 2. FRONTEND UI (Baris 241-1471)

#### A. Header Section (Baris 705-750)
```html
<div class="page-header">
  <div class="header-content">
    <h1>Manajemen Layanan</h1>
    <button class="btn-add" data-bs-toggle="modal" data-bs-target="#addModal">
      <i class="bi-plus-lg"></i> Tambah Layanan
    </button>
  </div>
  
  <!-- Stats Cards -->
  <div class="stats-cards">
    <div class="stat-card">
      <i class="bi-grid"></i>
      <div class="stat-info">
        <h3><?= count($services) ?></h3>
        <p>Total Layanan</p>
      </div>
    </div>
    <div class="stat-card">
      <i class="bi-check-circle"></i>
      <div class="stat-info">
        <h3><?= count(array_filter($services, fn($s) => $s['status'] === 'active')) ?></h3>
        <p>Aktif</p>
      </div>
    </div>
    <div class="stat-card">
      <i class="bi-x-circle"></i>
      <div class="stat-info">
        <h3><?= count(array_filter($services, fn($s) => $s['status'] === 'inactive')) ?></h3>
        <p>Tidak Aktif</p>
      </div>
    </div>
  </div>
</div>
```

**Stats Display:**
- Total Layanan (count all)
- Aktif (count active)
- Tidak Aktif (count inactive)

#### B. Filter Section (Baris 752-810)
```html
<div class="filters">
  <form method="GET" class="filter-form">
    <!-- Category Filter -->
    <select name="category" class="form-select">
      <option value="">Semua Kategori</option>
      <?php foreach ($categories as $cat): ?>
        <option value="<?= $cat['category'] ?>" <?= $filter_category === $cat['category'] ? 'selected' : '' ?>>
          <?= ucfirst($cat['category']) ?>
        </option>
      <?php endforeach; ?>
    </select>
    
    <!-- Status Filter -->
    <select name="status" class="form-select">
      <option value="">Semua Status</option>
      <option value="active" <?= $filter_status === 'active' ? 'selected' : '' ?>>Aktif</option>
      <option value="inactive" <?= $filter_status === 'inactive' ? 'selected' : '' ?>>Tidak Aktif</option>
    </select>
    
    <!-- Search Input -->
    <input type="text" name="search" class="form-control" placeholder="Cari layanan..." value="<?= htmlspecialchars($search) ?>">
    
    <button type="submit" class="btn-filter">
      <i class="bi-search"></i> Filter
    </button>
    
    <a href="services.php" class="btn-reset">
      <i class="bi-arrow-clockwise"></i> Reset
    </a>
  </form>
</div>
```

**Filter Options:**
- Category dropdown (dynamic from DB)
- Status dropdown (active/inactive)
- Search input (name/description)
- Filter button (submit)
- Reset button (clear all filters)

#### C. Services Grid (Baris 812-920)
```html
<div class="services-grid">
  <?php foreach ($services as $service): ?>
    <div class="service-card">
      <img src="<?= $service['image'] ?>" alt="<?= $service['name'] ?>">
      
      <div class="card-body">
        <span class="badge badge-<?= $service['status'] ?>">
          <?= ucfirst($service['status']) ?>
        </span>
        
        <h3><?= $service['name'] ?></h3>
        <p class="category"><?= $service['category'] ?></p>
        <p class="description"><?= substr($service['description'], 0, 100) ?>...</p>
        
        <div class="price">
          <span class="price-amount">Rp <?= number_format($service['price_start'], 0, ',', '.') ?></span>
          <span class="price-unit">/ <?= $service['price_unit'] ?></span>
        </div>
        
        <div class="features">
          <?php 
          $features = json_decode($service['features'], true);
          foreach (array_slice($features, 0, 3) as $feature): 
          ?>
            <span class="feature-tag"><?= $feature ?></span>
          <?php endforeach; ?>
        </div>
        
        <div class="card-actions">
          <button class="btn-edit" onclick="openEditModal(<?= $service['id'] ?>)">
            <i class="bi-pencil"></i> Edit
          </button>
          <button class="btn-delete" onclick="deleteService(<?= $service['id'] ?>)">
            <i class="bi-trash"></i> Delete
          </button>
          <button class="btn-view" onclick="viewDetail(<?= $service['id'] ?>)">
            <i class="bi-eye"></i> Detail
          </button>
        </div>
      </div>
    </div>
  <?php endforeach; ?>
</div>
```

**Card Components:**
- Service image
- Status badge (color-coded)
- Service name
- Category
- Description (truncated 100 chars)
- Price (formatted)
- Features (first 3 only)
- Action buttons (Edit, Delete, View)

#### D. Pagination (Baris 922-960)
```html
<div class="pagination">
  <?php if ($page > 1): ?>
    <a href="?page=<?= $page - 1 ?>&category=<?= $filter_category ?>&status=<?= $filter_status ?>&search=<?= $search ?>" class="page-link">
      <i class="bi-chevron-left"></i> Previous
    </a>
  <?php endif; ?>
  
  <?php for ($i = 1; $i <= $total_pages; $i++): ?>
    <a href="?page=<?= $i ?>&category=<?= $filter_category ?>&status=<?= $filter_status ?>&search=<?= $search ?>" class="page-link <?= $i === $page ? 'active' : '' ?>">
      <?= $i ?>
    </a>
  <?php endfor; ?>
  
  <?php if ($page < $total_pages): ?>
    <a href="?page=<?= $page + 1 ?>&category=<?= $filter_category ?>&status=<?= $filter_status ?>&search=<?= $search ?>" class="page-link">
      Next <i class="bi-chevron-right"></i>
    </a>
  <?php endif; ?>
</div>
```

**Features:**
- Previous/Next buttons
- Numbered page links
- Active page highlight
- Preserve filters in pagination

#### E. Modal Edit Service (Baris 962-1100)
```html
<div class="modal fade" id="editModal">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5>Edit Layanan</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      
      <form method="POST" class="modal-form">
        <input type="hidden" name="service_id" id="edit_service_id">
        
        <div class="form-group">
          <label>Nama Layanan *</label>
          <input type="text" name="name" id="edit_name" required>
        </div>
        
        <div class="form-group">
          <label>Kategori *</label>
          <input type="text" name="category" id="edit_category" required>
        </div>
        
        <div class="form-group">
          <label>Deskripsi *</label>
          <textarea name="description" id="edit_description" rows="4" required></textarea>
        </div>
        
        <div class="row">
          <div class="col-md-6">
            <label>Harga Mulai *</label>
            <input type="number" name="price_start" id="edit_price_start" required>
          </div>
          <div class="col-md-6">
            <label>Satuan Harga *</label>
            <input type="text" name="price_unit" id="edit_price_unit" placeholder="bulan/tahun/proyek" required>
          </div>
        </div>
        
        <div class="form-group">
          <label>URL Gambar</label>
          <input type="url" name="image" id="edit_image">
        </div>
        
        <div class="form-group">
          <label>Fitur-fitur</label>
          <div id="edit_features_container">
            <!-- Dynamic feature inputs -->
          </div>
          <button type="button" class="btn-add-feature" onclick="addFeature('edit')">
            <i class="bi-plus"></i> Tambah Fitur
          </button>
        </div>
        
        <div class="form-group">
          <label>Cocok Untuk</label>
          <input type="text" name="perfect_for" id="edit_perfect_for">
        </div>
        
        <div class="form-group">
          <label>Waktu Pengerjaan</label>
          <input type="text" name="delivery_time" id="edit_delivery_time" placeholder="7-14 hari">
        </div>
        
        <div class="form-group">
          <label>Status</label>
          <select name="status" id="edit_status" class="form-select">
            <option value="active">Aktif</option>
            <option value="inactive">Tidak Aktif</option>
          </select>
        </div>
        
        <div class="modal-footer">
          <button type="button" class="btn-secondary" data-bs-dismiss="modal">Batal</button>
          <button type="submit" name="update_service" class="btn-primary">
            Simpan Perubahan
          </button>
        </div>
      </form>
    </div>
  </div>
</div>
```

**Form Fields:**
- service_id (hidden)
- name (text, required)
- category (text, required)
- description (textarea, required)
- price_start (number, required)
- price_unit (text, required)
- image (url)
- features (dynamic array)
- perfect_for (text)
- delivery_time (text)
- status (select)

#### F. Modal Add Service
Same structure as Edit Modal, but without service_id field.

#### G. Modal View Detail
Similar structure, but all fields are readonly for viewing only.

### 3. JAVASCRIPT (Baris 1351-1471)

#### A. Feature Management
```javascript
// Add new feature input
function addFeature(prefix = '') {
    const container = document.getElementById(`${prefix}_features_container`);
    const index = container.children.length;
    
    const div = document.createElement('div');
    div.className = 'feature-input-group';
    div.innerHTML = `
        <input type="text" name="features[]" class="form-control" placeholder="Masukkan fitur">
        <button type="button" class="btn-remove" onclick="this.parentElement.remove()">
            <i class="bi-x"></i>
        </button>
    `;
    
    container.appendChild(div);
}

// Remove feature input
function removeFeature(button) {
    button.closest('.feature-input-group').remove();
}
```

#### B. Delete Service Confirmation
```javascript
function deleteService(id) {
    if (confirm('Apakah Anda yakin ingin menghapus layanan ini?')) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.innerHTML = `
            <input type="hidden" name="service_id" value="${id}">
            <input type="hidden" name="delete_service" value="1">
        `;
        document.body.appendChild(form);
        form.submit();
    }
}
```

#### C. Network Background Animation
Same as previous files (50 nodes, particle system).

## 📊 DATABASE SCHEMA

### Table: services
```sql
CREATE TABLE services (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  category VARCHAR(100) NOT NULL,
  description TEXT NOT NULL,
  price_start DECIMAL(15,2) NOT NULL,
  price_unit VARCHAR(50) NOT NULL,
  image VARCHAR(255),
  features JSON,
  perfect_for VARCHAR(255),
  delivery_time VARCHAR(100),
  status ENUM('active', 'inactive') DEFAULT 'active',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX (category),
  INDEX (status),
  INDEX (created_at)
);
```

## ✅ Fitur yang Sudah Ada

1. ✅ **CRUD Operations Lengkap**
   - Create (tambah layanan baru)
   - Read (view list & detail)
   - Update (edit layanan)
   - Delete (hapus layanan)

2. ✅ **Advanced Filtering**
   - Filter by category
   - Filter by status
   - Search by name/description
   - Combined filters

3. ✅ **Pagination**
   - 12 items per page
   - Previous/Next navigation
   - Numbered page links
   - Preserve filters

4. ✅ **Stats Dashboard**
   - Total layanan
   - Aktif count
   - Tidak aktif count

5. ✅ **Dynamic Features**
   - Add/remove feature fields
   - JSON storage
   - Display on cards

6. ✅ **Activity Logging**
   - Log all admin actions
   - Track changes

7. ✅ **UI/UX Premium**
   - Dark theme + gold accent
   - Glass-morphism cards
   - Smooth animations
   - Responsive design

8. ✅ **Security**
   - Role-based access (admin only)
   - Prepared statements
   - Input validation
   - XSS protection

## ⚠️ Improvements Needed

1. ❌ **Image Upload**
   - Upload dari local file
   - Image cropping
   - Multiple images

2. ❌ **Bulk Actions**
   - Select multiple services
   - Bulk delete
   - Bulk status change

3. ❌ **Export/Import**
   - Export to CSV/Excel
   - Import from file
   - Backup data

4. ❌ **Service Categories Management**
   - CRUD for categories
   - Category icons
   - Category colors

5. ❌ **Rich Text Editor**
   - WYSIWYG editor for description
   - Format text
   - Add images in description

6. ❌ **Service Templates**
   - Save as template
   - Duplicate service
   - Quick create from template

7. ❌ **Analytics**
   - Views per service
   - Popular services
   - Conversion tracking

## 🎯 Kesimpulan File Lanjutan45

**Rating: ⭐⭐⭐⭐⭐ (5/5)**

### Kelebihan:
✅ Complete CRUD operations  
✅ Advanced filtering & search  
✅ Pagination system  
✅ Dynamic features management  
✅ Beautiful admin UI  
✅ Activity logging  
✅ Role-based access  
✅ Responsive design  
✅ Security best practices  

### Kekurangan:
⚠️ No image upload (URL only)  
⚠️ No bulk actions  
⚠️ No rich text editor  

### Use Case:
Perfect untuk admin panel CMS, service management, product catalog, atau content management system.

---

**END OF BATCH 3**

_Lanjut ke Batch 4: Summary & Recommendations_
