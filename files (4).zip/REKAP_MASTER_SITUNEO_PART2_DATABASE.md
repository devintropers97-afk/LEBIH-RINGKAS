# 📋 REKAP MASTER LENGKAP SITUNEO.MY.ID
## PART 2: DATABASE STRUCTURE & 102 TABEL

---

## 🗄️ DATABASE OVERVIEW

**Database Name:** nrrskfvk_situneo_digital  
**Engine:** MariaDB 10.6.23  
**Character Set:** utf8mb4_unicode_ci  
**Total Tabel:** 102 tabel  
**Foreign Keys:** 150+ relationships  
**File Size:** 135 KB (SQL dump)  
**Total Baris SQL:** 4,573 baris

---

## 📊 BREAKDOWN KATEGORI TABEL

| Kategori | Jumlah | Keterangan |
|----------|--------|------------|
| User & Authentication | 8 | users, user_profiles, login_attempts, dll |
| Clients & CRM | 6 | clients, client_contacts, client_notes |
| Services & Products | 12 | services, packages, pricing_tiers |
| Orders & Transactions | 9 | orders, order_items, order_tracking |
| Partners & Referral | 14 | partners, referrals, commissions |
| SPV Management | 10 | spv, spv_reports, spv_arpu |
| Marketing & Content | 12 | campaigns, blog_posts, newsletters |
| Portfolio & Projects | 5 | portfolios, deliverables, milestones |
| Invoicing & Finance | 13 | invoices, payments, refunds |
| Support & Communication | 6 | support_tickets, messages, faqs |
| System & Admin | 7 | activity_logs, audit_logs, settings |

**TOTAL:** 102 tabel

---

## 📑 DAFTAR LENGKAP 102 TABEL (Alfabetis)

| No | Nama Tabel | Fields | Kategori | Keterangan |
|----|------------|--------|----------|------------|
| 1 | achievements | 7 | Gamification | Pencapaian user |
| 2 | activity_logs | 7 | System | Log aktivitas |
| 3 | admin_actions | 8 | Admin | Aksi admin |
| 4 | announcements | 9 | Communication | Pengumuman |
| 5 | api_keys | 10 | Integration | API management |
| 6 | audit_logs | 9 | Security | Audit trail |
| 7 | banners | 8 | Marketing | Banner promo |
| 8 | blog_categories | 5 | Content | Kategori blog |
| 9 | blog_posts | 15 | Content | Artikel blog |
| 10 | blog_tags | 4 | Content | Tag blog |
| 11 | business_categories | 10 | Service | Kategori bisnis (53) |
| 12 | campaigns | 17 | Marketing | Campaign marketing |
| 13 | campaign_analytics | 14 | Analytics | Analytics campaign |
| 14 | careers | 15 | HR | Lowongan kerja |
| 15 | clients | 13 | CRM | Data klien |
| 16 | client_contacts | 11 | CRM | Kontak klien |
| 17 | client_documents | 8 | CRM | Dokumen klien |
| 18 | client_interactions | 10 | CRM | Interaksi klien |
| 19 | client_notes | 6 | CRM | Catatan klien |
| 20 | client_subscriptions | 14 | Subscription | Langganan klien |
| 21 | commission_structure | 11 | Finance | Struktur komisi |
| 22 | currencies | 7 | Finance | Mata uang |
| 23 | custom_services | 15 | Service | Custom request |
| 24 | data_exports | 10 | System | Export data |
| 25 | deliverables | 13 | Project | Deliverable |
| 26 | discounts | 15 | Finance | Diskon |
| 27 | email_logs | 10 | Communication | Log email |
| 28 | email_templates | 10 | Communication | Template email |
| 29 | faqs | 7 | Support | FAQ umum |
| 30 | financial_reports | 12 | Finance | Laporan keuangan |
| 31 | industries | 6 | Master Data | Industri |
| 32 | integration_logs | 9 | Integration | Log integrasi |
| 33 | integrations | 11 | Integration | Setup integrasi |
| 34 | invoices | 13 | Finance | Invoice |
| 35 | invoice_items | 10 | Finance | Item invoice |
| 36 | job_applications | 13 | HR | Aplikasi kerja |
| 37 | leads | 18 | Sales | Lead management |
| 38 | lead_tracking | 10 | Sales | Tracking lead |
| 39 | locations | 10 | Master Data | Lokasi |
| 40 | login_attempts | 7 | Security | Tracking login |
| 41 | messages | 10 | Communication | Pesan internal |
| 42 | milestones | 12 | Project | Milestone project |
| 43 | milestone_approvals | 9 | Project | Approval milestone |
| 44 | newsletters | 12 | Marketing | Newsletter |
| 45 | notifications | 10 | Communication | Notifikasi |
| 46 | oauth_providers | 8 | Authentication | OAuth setup |
| 47 | oauth_tokens | 9 | Authentication | OAuth tokens |
| 48 | orders | 15 | Transaction | Pesanan |
| 49 | order_documents | 8 | Transaction | Dokumen order |
| 50 | order_items | 12 | Transaction | Item order |
| 51 | order_tracking | 9 | Transaction | Tracking order |
| 52 | packages | 16 | Service | Paket bundling |
| 53 | package_analytics | 11 | Analytics | Analytics paket |
| 54 | package_items | 8 | Service | Item paket |
| 55 | partners | 13 | Partner | Data partner |
| 56 | partner_applications | 11 | Partner | Aplikasi partner |
| 57 | partner_commissions | 11 | Partner | Komisi partner |
| 58 | partner_leads | 12 | Partner | Lead partner |
| 59 | partner_payouts | 11 | Partner | Payout partner |
| 60 | partner_tasks | 16 | Partner | Task partner |
| 61 | partner_tiers | 12 | Partner | Tier partner |
| 62 | partner_tier_history | 7 | Partner | History tier |
| 63 | partner_training | 15 | Partner | Training partner |
| 64 | password_resets | 5 | Authentication | Reset password |
| 65 | payments | 14 | Finance | Pembayaran |
| 66 | payment_methods | 9 | Finance | Metode bayar |
| 67 | portfolios | 16 | Portfolio | Portfolio project |
| 68 | portfolio_images | 7 | Portfolio | Gambar portfolio |
| 69 | post_tags | 3 | Content | Relasi post-tag |
| 70 | pricing_tiers | 12 | Service | Tier harga |
| 71 | referrals | 11 | Partner | Data referral |
| 72 | refunds | 11 | Finance | Refund |
| 73 | services | 24 | Service | 232+ Layanan digital |
| 74 | service_addons | 11 | Service | Add-on layanan |
| 75 | service_analytics | 14 | Analytics | Analytics layanan |
| 76 | service_faqs | 7 | Service | FAQ layanan |
| 77 | service_reviews | 11 | Service | Review layanan |
| 78 | spv | 12 | Management | Data SPV |
| 79 | spv_bonuses | 10 | Management | Bonus SPV |
| 80 | spv_communications | 9 | Management | Komunikasi SPV |
| 81 | spv_monthly_arpu | 11 | Management | ARPU bulanan |
| 82 | spv_partners | 6 | Management | Partner per SPV |
| 83 | spv_reports | 14 | Management | Laporan SPV |
| 84 | spv_targets | 12 | Management | Target SPV |
| 85 | spv_team_performance | 13 | Management | Performa tim |
| 86 | subscription_payments | 11 | Subscription | Pembayaran subscription |
| 87 | support_tickets | 13 | Support | Tiket support |
| 88 | tags | 6 | Content | Tags general |
| 89 | testimonials | 11 | Marketing | Testimonial klien |
| 90 | training_modules | 14 | Training | Modul training |
| 91 | training_progress | 9 | Training | Progress training |
| 92 | transactions | 16 | Finance | Transaksi umum |
| 93 | user_devices | 9 | Security | Device tracking |
| 94 | user_permissions | 7 | Authorization | Permission user |
| 95 | user_profiles | 15 | User | Profile extended |
| 96 | user_roles | 6 | Authorization | Role user |
| 97 | user_sessions | 9 | Authentication | Session management |
| 98 | users | 12 | User | User utama |
| 99 | user_settings | 8 | User | Settings user |
| 100 | websites | 18 | Portfolio | Demo websites (50) |
| 101 | withdrawals | 13 | Finance | Withdrawal request |
| 102 | withdrawal_approvals | 10 | Finance | Approval withdrawal |

---

## 🔑 TABEL UTAMA & DETAIL

### 1. USERS (User Utama)
**Fields:** 12 fields

| Field | Type | Description |
|-------|------|-------------|
| id | INT(11) | Primary key |
| username | VARCHAR(50) | Username unik |
| email | VARCHAR(100) | Email unik |
| password_hash | VARCHAR(255) | Password encrypted |
| full_name | VARCHAR(100) | Nama lengkap |
| phone | VARCHAR(20) | No telepon |
| role | ENUM | admin/partner/client/spv |
| status | ENUM | active/inactive/suspended |
| email_verified | TINYINT(1) | Status verifikasi |
| last_login | DATETIME | Login terakhir |
| created_at | TIMESTAMP | Waktu dibuat |
| updated_at | TIMESTAMP | Waktu update |

**Relations:**
- Has many: orders, payments, partners, clients, spv

---

### 2. SERVICES (232+ Layanan)
**Fields:** 24 fields

| Field | Type | Description |
|-------|------|-------------|
| id | INT(11) | Primary key |
| service_code | VARCHAR(20) | Kode unik |
| name | VARCHAR(255) | Nama layanan |
| slug | VARCHAR(255) | URL-friendly |
| category_id | INT(11) | FK to categories |
| division | ENUM | 10 divisi |
| description | TEXT | Deskripsi lengkap |
| features | TEXT | Fitur-fitur (JSON) |
| price_min | DECIMAL(15,2) | Harga minimum |
| price_max | DECIMAL(15,2) | Harga maximum |
| duration_min | INT(11) | Waktu min (hari) |
| duration_max | INT(11) | Waktu max (hari) |
| image | VARCHAR(255) | Gambar layanan |
| is_featured | TINYINT(1) | Layanan unggulan |
| is_active | TINYINT(1) | Status aktif |
| rating_average | DECIMAL(3,2) | Rating rata-rata |
| total_orders | INT(11) | Total pesanan |
| seo_title | VARCHAR(255) | SEO title |
| seo_description | TEXT | SEO description |
| meta_keywords | VARCHAR(255) | Keywords |
| created_at | TIMESTAMP | Waktu dibuat |
| updated_at | TIMESTAMP | Waktu update |

**Relations:**
- Belongs to: business_categories
- Has many: orders, reviews, faqs, addons

---

### 3. ORDERS (Pesanan)
**Fields:** 15 fields

| Field | Type | Description |
|-------|------|-------------|
| id | INT(11) | Primary key |
| order_number | VARCHAR(50) | Nomor order unik |
| user_id | INT(11) | FK to users (client) |
| service_id | INT(11) | FK to services |
| status | ENUM | pending/processing/completed/cancelled |
| total_amount | DECIMAL(15,2) | Total harga |
| payment_status | ENUM | unpaid/paid/refunded |
| payment_method | VARCHAR(50) | Metode pembayaran |
| requirements | TEXT | Kebutuhan client (26 fields) |
| notes | TEXT | Catatan tambahan |
| started_at | DATETIME | Mulai dikerjakan |
| completed_at | DATETIME | Selesai dikerjakan |
| created_at | TIMESTAMP | Waktu dibuat |
| updated_at | TIMESTAMP | Waktu update |

**Relations:**
- Belongs to: users (client), services
- Has many: order_items, payments, invoices

---

### 4. PARTNERS (Partner/Affiliate)
**Fields:** 13 fields

| Field | Type | Description |
|-------|------|-------------|
| id | INT(11) | Primary key |
| user_id | INT(11) | FK to users |
| partner_code | VARCHAR(20) | Kode partner unik |
| tier | ENUM | bronze/silver/gold/platinum |
| commission_rate | DECIMAL(5,2) | Persentase komisi |
| total_earnings | DECIMAL(15,2) | Total penghasilan |
| total_referrals | INT(11) | Total referral |
| total_orders | INT(11) | Total order |
| spv_id | INT(11) | FK to spv (atasan) |
| status | ENUM | active/inactive/suspended |
| approved_at | DATETIME | Tanggal approval |
| created_at | TIMESTAMP | Waktu dibuat |
| updated_at | TIMESTAMP | Waktu update |

**Relations:**
- Belongs to: users, spv
- Has many: referrals, commissions, payouts

---

### 5. SPV (Supervisor)
**Fields:** 12 fields

| Field | Type | Description |
|-------|------|-------------|
| id | INT(11) | Primary key |
| user_id | INT(11) | FK to users |
| spv_code | VARCHAR(20) | Kode SPV unik |
| region | VARCHAR(100) | Wilayah kerja |
| team_size | INT(11) | Jumlah partner |
| monthly_target | DECIMAL(15,2) | Target bulanan |
| total_achieved | DECIMAL(15,2) | Total tercapai |
| performance_score | DECIMAL(5,2) | Skor performa |
| status | ENUM | active/inactive |
| created_at | TIMESTAMP | Waktu dibuat |
| updated_at | TIMESTAMP | Waktu update |

**Relations:**
- Belongs to: users
- Has many: partners, spv_reports, spv_monthly_arpu

---

### 6. PARTNER_COMMISSIONS (Komisi Partner)
**Fields:** 11 fields

| Field | Type | Description |
|-------|------|-------------|
| id | INT(11) | Primary key |
| partner_id | INT(11) | FK to partners |
| order_id | INT(11) | FK to orders |
| order_amount | DECIMAL(15,2) | Nilai order |
| commission_rate | DECIMAL(5,2) | Rate komisi |
| commission_amount | DECIMAL(15,2) | Jumlah komisi |
| status | ENUM | pending/paid/cancelled |
| paid_at | DATETIME | Tanggal dibayar |
| created_at | TIMESTAMP | Waktu dibuat |
| updated_at | TIMESTAMP | Waktu update |

**Trigger:** Order LUNAS + Admin APPROVE

---

### 7. INVOICES (Invoice/Faktur)
**Fields:** 13 fields

| Field | Type | Description |
|-------|------|-------------|
| id | INT(11) | Primary key |
| invoice_number | VARCHAR(50) | INV-SITUNEO-DD-MMM-YYYY |
| order_id | INT(11) | FK to orders |
| client_id | INT(11) | FK to clients |
| total_amount | DECIMAL(15,2) | Total invoice |
| tax_amount | DECIMAL(15,2) | Pajak (jika ada) |
| status | ENUM | draft/sent/paid/cancelled |
| issued_at | DATE | Tanggal terbit |
| due_date | DATE | Tanggal jatuh tempo |
| paid_at | DATETIME | Tanggal dibayar |
| created_at | TIMESTAMP | Waktu dibuat |
| updated_at | TIMESTAMP | Waktu update |

**Auto Email:** Ya, setelah admin generate

---

### 8. PAYMENTS (Pembayaran)
**Fields:** 14 fields

| Field | Type | Description |
|-------|------|-------------|
| id | INT(11) | Primary key |
| order_id | INT(11) | FK to orders |
| invoice_id | INT(11) | FK to invoices |
| amount | DECIMAL(15,2) | Jumlah bayar |
| payment_method | VARCHAR(50) | Metode bayar |
| proof_image | VARCHAR(255) | Bukti transfer |
| status | ENUM | pending/verified/rejected |
| verified_by | INT(11) | Admin yang verifikasi |
| verified_at | DATETIME | Waktu verifikasi |
| notes | TEXT | Catatan admin |
| created_at | TIMESTAMP | Waktu dibuat |
| updated_at | TIMESTAMP | Waktu update |

**Manual Payment:** Upload bukti transfer, admin approve

---

## 🗺️ DATABASE RELATIONSHIP MAP

```
┌──────────┐
│  USERS   │ (Master User Table)
│          │
└────┬─────┘
     │
     ├──────────┬──────────┬──────────┐
     ▼          ▼          ▼          ▼
┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐
│ CLIENTS │ │ PARTNERS│ │   SPV   │ │  ADMIN  │
└────┬────┘ └────┬────┘ └────┬────┘ └─────────┘
     │           │           │
     │           │           │
     ▼           ▼           ▼
┌─────────┐ ┌─────────┐ ┌─────────┐
│ ORDERS  │ │REFERRALS│ │SPV_ARPU │
└────┬────┘ └────┬────┘ └─────────┘
     │           │
     │           │
     ▼           ▼
┌─────────┐ ┌─────────┐
│PAYMENTS │ │COMMISS. │
└────┬────┘ └─────────┘
     │
     ▼
┌─────────┐
│INVOICES │
└─────────┘
```

### Referral Hierarchy:
```
Manager Area
    ↓
   SPV (Supervisor)
    ↓
 Partner (Affiliate)
    ↓
 Client (Customer)
```

### Commission Flow:
```
Client Order → Payment → Admin Approve
     ↓
Partner Commission (10%)
     ↓
SPV Bonus (5%)
     ↓
Manager Bonus (3%)
```

---

## 💡 CATATAN PENTING

1. **Services Table** adalah core - berisi 232+ layanan
2. **Referral System** menggunakan 3 tabel: users, partners, spv
3. **Commission** dihitung real-time setelah order ACC + lunas
4. **ARPU** dihitung otomatis untuk SPV dashboard
5. **Email Notifications** menggunakan email_logs & email_templates
6. **All relationships** menggunakan Foreign Keys dengan CASCADE
7. **Security** dijaga dengan audit_logs, activity_logs, login_attempts

---

**NEXT:** Part 3 - 232 Services Catalog & 10 Divisi

---

**© 2025 REKAP MASTER SITUNEO - Database Documentation**
